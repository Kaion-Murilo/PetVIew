﻿namespace PetView
{
    partial class Agendamento
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cboAnimal = new System.Windows.Forms.ComboBox();
            this.cboTipoAgendamento = new System.Windows.Forms.ComboBox();
            this.cboDono = new System.Windows.Forms.ComboBox();
            this.cboMed = new System.Windows.Forms.ComboBox();
            this.dtpData = new System.Windows.Forms.DateTimePicker();
            this.dtpHora = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.rtxtObs = new System.Windows.Forms.RichTextBox();
            this.lblConsultaAnterior = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cboTipo = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.nupCusto = new System.Windows.Forms.NumericUpDown();
            this.cboConsulta = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnCadastrar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupCusto)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label7, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.label6, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.cboAnimal, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.cboTipoAgendamento, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.cboDono, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.cboMed, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.dtpData, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.dtpHora, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.label9, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.rtxtObs, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.lblConsultaAnterior, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.label10, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.cboTipo, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label5, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.nupCusto, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.cboConsulta, 3, 4);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 66);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.Padding = new System.Windows.Forms.Padding(27, 25, 27, 25);
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 68F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 68F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 68F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 68F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 215F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1560, 685);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Calibri", 13F);
            this.label8.Location = new System.Drawing.Point(31, 233);
            this.label8.Margin = new System.Windows.Forms.Padding(4);
            this.label8.Name = "label8";
            this.label8.Padding = new System.Windows.Forms.Padding(47, 12, 13, 12);
            this.label8.Size = new System.Drawing.Size(293, 60);
            this.label8.TabIndex = 18;
            this.label8.Text = "Médico:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Calibri", 13F);
            this.label7.Location = new System.Drawing.Point(783, 165);
            this.label7.Margin = new System.Windows.Forms.Padding(4);
            this.label7.Name = "label7";
            this.label7.Padding = new System.Windows.Forms.Padding(47, 12, 13, 12);
            this.label7.Size = new System.Drawing.Size(293, 60);
            this.label7.TabIndex = 17;
            this.label7.Text = "Hora:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Calibri", 13F);
            this.label6.Location = new System.Drawing.Point(783, 97);
            this.label6.Margin = new System.Windows.Forms.Padding(4);
            this.label6.Name = "label6";
            this.label6.Padding = new System.Windows.Forms.Padding(47, 12, 13, 12);
            this.label6.Size = new System.Drawing.Size(293, 60);
            this.label6.TabIndex = 11;
            this.label6.Text = "Animal:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 13F);
            this.label1.Location = new System.Drawing.Point(31, 29);
            this.label1.Margin = new System.Windows.Forms.Padding(4);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(47, 12, 13, 12);
            this.label1.Size = new System.Drawing.Size(278, 51);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tipo de agendamento:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Calibri", 13F);
            this.label2.Location = new System.Drawing.Point(31, 97);
            this.label2.Margin = new System.Windows.Forms.Padding(4);
            this.label2.Name = "label2";
            this.label2.Padding = new System.Windows.Forms.Padding(47, 12, 13, 12);
            this.label2.Size = new System.Drawing.Size(293, 60);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nome do dono:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Calibri", 13F);
            this.label3.Location = new System.Drawing.Point(31, 165);
            this.label3.Margin = new System.Windows.Forms.Padding(4);
            this.label3.Name = "label3";
            this.label3.Padding = new System.Windows.Forms.Padding(47, 12, 13, 12);
            this.label3.Size = new System.Drawing.Size(293, 60);
            this.label3.TabIndex = 2;
            this.label3.Text = "Data:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cboAnimal
            // 
            this.cboAnimal.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cboAnimal.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboAnimal.Font = new System.Drawing.Font("Calibri", 13F);
            this.cboAnimal.FormattingEnabled = true;
            this.cboAnimal.Location = new System.Drawing.Point(1096, 109);
            this.cboAnimal.Margin = new System.Windows.Forms.Padding(4);
            this.cboAnimal.Name = "cboAnimal";
            this.cboAnimal.Size = new System.Drawing.Size(421, 35);
            this.cboAnimal.TabIndex = 9;
            this.cboAnimal.TextChanged += new System.EventHandler(this.cboAnimal_TextChanged);
            // 
            // cboTipoAgendamento
            // 
            this.cboTipoAgendamento.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cboTipoAgendamento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTipoAgendamento.Font = new System.Drawing.Font("Calibri", 13F);
            this.cboTipoAgendamento.FormattingEnabled = true;
            this.cboTipoAgendamento.Location = new System.Drawing.Point(342, 41);
            this.cboTipoAgendamento.Margin = new System.Windows.Forms.Padding(4);
            this.cboTipoAgendamento.Name = "cboTipoAgendamento";
            this.cboTipoAgendamento.Size = new System.Drawing.Size(423, 35);
            this.cboTipoAgendamento.TabIndex = 4;
            this.cboTipoAgendamento.TextChanged += new System.EventHandler(this.cboTipoAgendamento_TextChanged);
            // 
            // cboDono
            // 
            this.cboDono.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cboDono.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDono.Font = new System.Drawing.Font("Calibri", 13F);
            this.cboDono.FormattingEnabled = true;
            this.cboDono.Location = new System.Drawing.Point(343, 109);
            this.cboDono.Margin = new System.Windows.Forms.Padding(4);
            this.cboDono.Name = "cboDono";
            this.cboDono.Size = new System.Drawing.Size(421, 35);
            this.cboDono.TabIndex = 6;
            this.cboDono.TextChanged += new System.EventHandler(this.cboDono_TextChanged);
            // 
            // cboMed
            // 
            this.cboMed.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cboMed.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMed.Font = new System.Drawing.Font("Calibri", 13F);
            this.cboMed.FormattingEnabled = true;
            this.cboMed.Location = new System.Drawing.Point(343, 245);
            this.cboMed.Margin = new System.Windows.Forms.Padding(4);
            this.cboMed.Name = "cboMed";
            this.cboMed.Size = new System.Drawing.Size(421, 35);
            this.cboMed.TabIndex = 19;
            // 
            // dtpData
            // 
            this.dtpData.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtpData.CustomFormat = "yyyy-MM-dd";
            this.dtpData.Font = new System.Drawing.Font("Calibri", 13F);
            this.dtpData.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpData.Location = new System.Drawing.Point(343, 178);
            this.dtpData.Margin = new System.Windows.Forms.Padding(4);
            this.dtpData.Name = "dtpData";
            this.dtpData.Size = new System.Drawing.Size(420, 34);
            this.dtpData.TabIndex = 5;
            this.dtpData.Value = new System.DateTime(2024, 6, 24, 23, 59, 59, 0);
            // 
            // dtpHora
            // 
            this.dtpHora.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtpHora.CustomFormat = "HH:MM";
            this.dtpHora.Font = new System.Drawing.Font("Calibri", 13F);
            this.dtpHora.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpHora.Location = new System.Drawing.Point(1096, 178);
            this.dtpHora.Margin = new System.Windows.Forms.Padding(4);
            this.dtpHora.Name = "dtpHora";
            this.dtpHora.ShowUpDown = true;
            this.dtpHora.Size = new System.Drawing.Size(420, 34);
            this.dtpHora.TabIndex = 21;
            this.dtpHora.Value = new System.DateTime(2019, 4, 13, 16, 37, 0, 0);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 13F);
            this.label9.Location = new System.Drawing.Point(31, 301);
            this.label9.Margin = new System.Windows.Forms.Padding(4);
            this.label9.Name = "label9";
            this.label9.Padding = new System.Windows.Forms.Padding(47, 12, 13, 12);
            this.label9.Size = new System.Drawing.Size(195, 51);
            this.label9.TabIndex = 20;
            this.label9.Text = "Observações:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rtxtObs
            // 
            this.rtxtObs.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.rtxtObs.Font = new System.Drawing.Font("Calibri", 13F);
            this.rtxtObs.Location = new System.Drawing.Point(348, 317);
            this.rtxtObs.Margin = new System.Windows.Forms.Padding(20, 18, 20, 18);
            this.rtxtObs.Name = "rtxtObs";
            this.rtxtObs.Size = new System.Drawing.Size(411, 175);
            this.rtxtObs.TabIndex = 22;
            this.rtxtObs.Text = "";
            // 
            // lblConsultaAnterior
            // 
            this.lblConsultaAnterior.AutoSize = true;
            this.lblConsultaAnterior.Font = new System.Drawing.Font("Calibri", 13F);
            this.lblConsultaAnterior.Location = new System.Drawing.Point(783, 301);
            this.lblConsultaAnterior.Margin = new System.Windows.Forms.Padding(4);
            this.lblConsultaAnterior.Name = "lblConsultaAnterior";
            this.lblConsultaAnterior.Padding = new System.Windows.Forms.Padding(47, 12, 13, 12);
            this.lblConsultaAnterior.Size = new System.Drawing.Size(237, 51);
            this.lblConsultaAnterior.TabIndex = 25;
            this.lblConsultaAnterior.Text = "Consulta anterior:";
            this.lblConsultaAnterior.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblConsultaAnterior.Visible = false;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 13F);
            this.label10.Location = new System.Drawing.Point(783, 33);
            this.label10.Margin = new System.Windows.Forms.Padding(4);
            this.label10.Name = "label10";
            this.label10.Padding = new System.Windows.Forms.Padding(47, 12, 13, 12);
            this.label10.Size = new System.Drawing.Size(118, 51);
            this.label10.TabIndex = 23;
            this.label10.Text = "Tipo:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cboTipo
            // 
            this.cboTipo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cboTipo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTipo.Font = new System.Drawing.Font("Calibri", 13F);
            this.cboTipo.FormattingEnabled = true;
            this.cboTipo.Location = new System.Drawing.Point(1096, 41);
            this.cboTipo.Margin = new System.Windows.Forms.Padding(4);
            this.cboTipo.Name = "cboTipo";
            this.cboTipo.Size = new System.Drawing.Size(421, 35);
            this.cboTipo.TabIndex = 24;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 13F);
            this.label5.Location = new System.Drawing.Point(783, 237);
            this.label5.Margin = new System.Windows.Forms.Padding(4);
            this.label5.Name = "label5";
            this.label5.Padding = new System.Windows.Forms.Padding(47, 12, 13, 12);
            this.label5.Size = new System.Drawing.Size(130, 51);
            this.label5.TabIndex = 27;
            this.label5.Text = "Custo:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nupCusto
            // 
            this.nupCusto.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nupCusto.DecimalPlaces = 2;
            this.nupCusto.Font = new System.Drawing.Font("Calibri", 13F);
            this.nupCusto.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nupCusto.Location = new System.Drawing.Point(1099, 246);
            this.nupCusto.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nupCusto.Name = "nupCusto";
            this.nupCusto.Size = new System.Drawing.Size(415, 34);
            this.nupCusto.TabIndex = 28;
            // 
            // cboConsulta
            // 
            this.cboConsulta.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cboConsulta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboConsulta.Font = new System.Drawing.Font("Calibri", 13F);
            this.cboConsulta.FormattingEnabled = true;
            this.cboConsulta.Location = new System.Drawing.Point(1096, 312);
            this.cboConsulta.Margin = new System.Windows.Forms.Padding(4, 15, 4, 4);
            this.cboConsulta.Name = "cboConsulta";
            this.cboConsulta.Size = new System.Drawing.Size(421, 35);
            this.cboConsulta.TabIndex = 26;
            this.cboConsulta.Visible = false;
            // 
            // label17
            // 
            this.label17.Dock = System.Windows.Forms.DockStyle.Top;
            this.label17.Font = new System.Drawing.Font("Calibri", 14F);
            this.label17.Location = new System.Drawing.Point(0, 0);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Padding = new System.Windows.Forms.Padding(0, 12, 0, 0);
            this.label17.Size = new System.Drawing.Size(1560, 66);
            this.label17.TabIndex = 6;
            this.label17.Text = "Novo agendamento";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.btnCadastrar);
            this.flowLayoutPanel1.Controls.Add(this.btnCancelar);
            this.flowLayoutPanel1.Controls.Add(this.btnLimpar);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 751);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Padding = new System.Windows.Forms.Padding(0, 0, 27, 0);
            this.flowLayoutPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1560, 123);
            this.flowLayoutPanel1.TabIndex = 9;
            // 
            // btnCadastrar
            // 
            this.btnCadastrar.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastrar.Location = new System.Drawing.Point(1287, 12);
            this.btnCadastrar.Margin = new System.Windows.Forms.Padding(13, 12, 13, 12);
            this.btnCadastrar.Name = "btnCadastrar";
            this.btnCadastrar.Size = new System.Drawing.Size(233, 62);
            this.btnCadastrar.TabIndex = 17;
            this.btnCadastrar.Text = "Cadastrar";
            this.btnCadastrar.UseVisualStyleBackColor = true;
            this.btnCadastrar.Click += new System.EventHandler(this.btnCadastrar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCancelar.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelar.Location = new System.Drawing.Point(1028, 12);
            this.btnCancelar.Margin = new System.Windows.Forms.Padding(13, 12, 13, 12);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(233, 62);
            this.btnCancelar.TabIndex = 16;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnLimpar.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(769, 12);
            this.btnLimpar.Margin = new System.Windows.Forms.Padding(13, 12, 13, 12);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(233, 62);
            this.btnLimpar.TabIndex = 18;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // Agendamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.label17);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Agendamento";
            this.Size = new System.Drawing.Size(1560, 874);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupCusto)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cboTipoAgendamento;
        private System.Windows.Forms.DateTimePicker dtpData;
        private System.Windows.Forms.ComboBox cboDono;
        private System.Windows.Forms.ComboBox cboAnimal;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cboMed;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dtpHora;
        private System.Windows.Forms.RichTextBox rtxtObs;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btnCadastrar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cboTipo;
        private System.Windows.Forms.Label lblConsultaAnterior;
        private System.Windows.Forms.ComboBox cboConsulta;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nupCusto;
    }
}
